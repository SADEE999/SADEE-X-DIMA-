# SADEE X DIMA ADMIN

Files:
- `admin.html` — standalone admin dashboard
- `supabase.sql` — database tables, RLS and admin function

## Setup

1. Open Supabase Dashboard for project `cpmzjplfqggmgeotmtcd`.
2. Go to SQL Editor and run `supabase.sql`.
3. Go to Authentication > Users and create your admin email/password.
4. Copy the created user's UUID.
5. In SQL Editor run:
   insert into public.admin_users(user_id) values ('YOUR-UUID-HERE');

## Deploy

Upload `admin.html` to the GitHub repository. For GitHub Pages you can put it at:
`admin.html`

Then open:
`https://YOUR-USERNAME.github.io/SADEE-X-DIMA-/admin.html`

## Security

The browser uses the Supabase publishable key. It is intentionally not a secret. RLS and the `admin_users` table protect admin data.

Never put a Supabase `sb_secret_...`, legacy `service_role`, database password, or other server secret into `admin.html`.

## Main app integration

The main optimizer can read:
- `app_settings`
- `sensitivity_presets`
- active `announcements`

and insert:
- `device_profiles`
- `optimization_logs`

The current deterministic preset values are seeded from the existing optimizer design.
